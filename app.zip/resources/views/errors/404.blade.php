@extends('layouts.website')

@section('title')
    Not Found 
@endsection

@section('content')
    <h2>404 Not Found</h2>
@endsection
